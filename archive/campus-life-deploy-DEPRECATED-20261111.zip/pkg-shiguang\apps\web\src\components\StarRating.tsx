'use client';

import { useState } from 'react';

const LABELS = ['不太满意', '有待改进', '还可以', '挺不错', '非常喜欢'];
const STAR_PATH = 'M18 3l4.4 9.1 10 1.4-7.2 7 1.7 10-8.9-4.7-8.9 4.7 1.7-10-7.2-7 10-1.4L18 3z';

interface Props {
  value: number;
  onChange: (value: number) => void;
  size?: number;
  readOnly?: boolean;
}

/** 真正可交互的五角星：悬停 / 点击 / 触摸反馈，每档有对应文案。 */
export function StarRating({ value, onChange, size = 36, readOnly = false }: Props) {
  const [hover, setHover] = useState(0);
  const shown = hover || value;

  return (
    <div className="flex flex-col gap-2">
      <div className="flex items-center gap-2" role="radiogroup" aria-label="五星评分">
        {[1, 2, 3, 4, 5].map((i) => (
          <button
            key={i}
            type="button"
            role="radio"
            aria-checked={value === i}
            aria-label={`${i} 星 · ${LABELS[i - 1]}`}
            disabled={readOnly}
            onMouseEnter={() => !readOnly && setHover(i)}
            onMouseLeave={() => !readOnly && setHover(0)}
            onTouchStart={() => !readOnly && setHover(i)}
            onClick={() => { if (!readOnly) { onChange(i); setHover(0); } }}
            className="rounded-lg p-1 transition-transform active:scale-90 disabled:cursor-default"
          >
            <svg width={size} height={size} viewBox="0 0 36 36" aria-hidden>
              <path d={STAR_PATH} fill={i <= shown ? '#FFB648' : '#EDE6DA'} stroke={i <= shown ? '#F0A93A' : 'none'} strokeWidth="1" />
            </svg>
          </button>
        ))}
      </div>
      <p className="text-xs font-semibold text-orange-deep" aria-live="polite">
        {shown > 0 ? `${shown} 星 · ${LABELS[shown - 1]}` : '轻点星星即可评分'}
      </p>
    </div>
  );
}
