import Link from 'next/link';
import { ArrowRight, Sparkles, Star, TrendingUp } from 'lucide-react';

export default function Home() {
  return (
    <main className="min-h-screen bg-cream dark:bg-[#1C201B]">
      <section className="bg-gradient-to-r from-[#FF9A5C] to-orange-deep px-6 pb-16 pt-10 text-white">
        <div className="mx-auto max-w-5xl">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl bg-white/20 text-xl font-bold">食</div>
            <div>
              <p className="text-2xl font-bold">食光有数</p>
              <p className="text-xs opacity-90">荔园智慧膳食服务平台</p>
            </div>
          </div>
          <h1 className="mt-14 max-w-xl text-4xl font-bold leading-tight sm:text-5xl">每一餐，都更懂你的口味。</h1>
          <p className="mt-4 max-w-lg text-sm opacity-95">
            菜单公示 · 提前点餐 · 预约取餐 · 评分反馈 · 营养分析 · 个性化菜品推荐。
            不依赖付费 AI API，用真实数据跑通「偏好—推荐—消费—反馈—画像更新」闭环。
          </p>
          <div className="mt-8 flex flex-wrap gap-3">
            <Link href="/dashboard" className="inline-flex items-center gap-2 rounded-pill bg-white px-6 py-3 text-sm font-bold text-orange-deep">
              进入平台 <ArrowRight size={16} aria-hidden />
            </Link>
            <Link href="/login" className="rounded-pill border border-white/60 px-6 py-3 text-sm font-semibold">登录 / 注册</Link>
          </div>
        </div>
      </section>

      <section className="mx-auto max-w-5xl px-6 py-12">
        <h2 className="text-xl font-bold">三个值得在答辩里重点演示的交互</h2>
        <div className="mt-6 grid gap-4 sm:grid-cols-3">
          {[
            { icon: Sparkles, title: '今天吃什么', desc: '按个人口味画像给出 3 道菜，附匹配理由、价格与食堂，而不是热门榜。' },
            { icon: Star, title: '饭后 10 秒反馈', desc: '五星打分 + 体感标签 + 可选短评，结构化数据真实影响下一次推荐。' },
            { icon: TrendingUp, title: '越来越懂你', desc: '标签与图表呈现偏好变化，明确区分「我设置的」与「系统推断」。' },
          ].map(({ icon: Icon, title, desc }) => (
            <article key={title} className="sg-card p-5">
              <Icon size={22} className="text-orange" aria-hidden />
              <h3 className="mt-3 font-bold">{title}</h3>
              <p className="mt-2 text-xs leading-5 text-muted">{desc}</p>
            </article>
          ))}
        </div>
        <div className="sg-card mt-6 p-5 text-xs leading-6 text-muted">
          <strong className="text-ink dark:text-cream">演示说明：</strong>
          支付为「到店付款」演示模式，未接入真实支付 / 校园一卡通 / 统一身份认证；
          营养数值为示例估算，非实验室检测结果；菜品图片为演示占位资源。
          演示账号密码由 <code>DEMO_PASSWORD</code> 注入，生产环境必须关闭演示账号。
        </div>
      </section>
    </main>
  );
}
