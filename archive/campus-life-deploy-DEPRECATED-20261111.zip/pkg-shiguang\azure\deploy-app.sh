#!/usr/bin/env bash
# =============================================================================
# 在 Azure VM 里运行：解压部署包 → 生成 .env → 构建并启动整套服务
#
# 前置：
#   scp campus-life-deploy.zip  azureuser@<IP>:/opt/shiguang/
#   scp deploy-app.sh           azureuser@<IP>:/opt/shiguang/
#
# 用法：
#   ssh azureuser@<IP> 'bash /opt/shiguang/deploy-app.sh'
#
# 可重复执行：已存在 .env 会保留，不会重新生成密钥。
# =============================================================================
set -euo pipefail

# 如果是从解压目录里执行的，先把自己复制到 /tmp ——
# 否则下面的 rm -rf pkg-shiguang 会把正在运行的脚本一起删掉。
if [[ "$0" == *"/pkg-shiguang/"* ]]; then
  cp "$0" /tmp/deploy-app.sh
  exec bash /tmp/deploy-app.sh "$@"
fi

APP_DIR="${APP_DIR:-/opt/shiguang}"
DOMAIN="${DOMAIN:-campus-life.ccwu.cc}"
ZIP="${ZIP:-$APP_DIR/campus-life-deploy.zip}"

say() { printf "\n\033[1;36m==> %s\033[0m\n" "$*"; }
die() { printf "\n\033[1;31m[失败] %s\033[0m\n" "$*" >&2; exit 1; }

[ -f "$ZIP" ] || die "找不到部署包 $ZIP。请先在本机执行：scp campus-life-deploy.zip ${USER:-azureuser}@<IP>:$APP_DIR/"

cd "$APP_DIR"
command -v unzip >/dev/null || die "缺少 unzip，请先 sudo apt-get install -y unzip"
command -v docker >/dev/null || die "Docker 未安装完成，请等 cloud-init 跑完：cloud-init status --wait"
docker compose version >/dev/null 2>&1 || die "docker compose 不可用"

say "解压部署包"
rm -rf pkg-shiguang
unzip -oq "$ZIP"
[ -d pkg-shiguang ] || die "压缩包结构异常，未找到 pkg-shiguang 目录"
cd pkg-shiguang

say "准备 .env"
if [ -f .env ]; then
  echo "已存在 .env，保留原有密钥（如需重置请先删除 .env）"
else
  cp .env.production.example .env
  DB_PASS=$(openssl rand -hex 16)
  ACCESS=$(openssl rand -base64 48 | tr -d '\n')
  REFRESH=$(openssl rand -base64 48 | tr -d '\n')
  DEMO_PASS=$(openssl rand -hex 6)

  sed -i "s|CHANGE_ME_DB_PASSWORD|${DB_PASS}|g" .env
  sed -i "s|CHANGE_ME_ACCESS_SECRET|${ACCESS}|g" .env
  sed -i "s|CHANGE_ME_REFRESH_SECRET|${REFRESH}|g" .env
  sed -i "s|CHANGE_ME_DEMO_PASSWORD|${DEMO_PASS}|g" .env
  sed -i "s|^COOKIE_DOMAIN=.*|COOKIE_DOMAIN=${DOMAIN}|" .env
  sed -i "s|^WEB_ORIGIN=.*|WEB_ORIGIN=https://${DOMAIN}|" .env

  echo "已生成随机密钥，演示账号密码：${DEMO_PASS}"
  echo "$DEMO_PASS" > "$APP_DIR/demo-password.txt"
  chmod 600 "$APP_DIR/demo-password.txt"
fi

say "检查 TLS 证书"
if [ -f infra/certs/fullchain.pem ] && [ -f infra/certs/privkey.pem ]; then
  echo "已找到证书，将启用 HTTPS（443）"
  sed -i "s|^COOKIE_SECURE=.*|COOKIE_SECURE=true|" .env
  COMPOSE_ARGS="-f docker-compose.yml -f docker-compose.prod.yml"
else
  echo "未找到 infra/certs/fullchain.pem，先只开 HTTP（80）"
  # HTTP 下必须关掉 Secure Cookie，否则浏览器不会回传，表现为「登录后又跳回登录页」
  sed -i "s|^COOKIE_SECURE=.*|COOKIE_SECURE=false|" .env
  echo "已临时把 COOKIE_SECURE 设为 false；接入证书后重跑本脚本会自动改回 true。"
  echo "建议：Cloudflare → SSL/TLS → Origin Server 生成证书，"
  echo "      把 fullchain.pem / privkey.pem 放进 $APP_DIR/pkg-shiguang/infra/certs/ 后重跑本脚本"
  COMPOSE_ARGS="-f docker-compose.yml"
fi

say "构建镜像（首次约 8-15 分钟）"
docker compose $COMPOSE_ARGS build

say "启动服务"
docker compose $COMPOSE_ARGS up -d

say "等待 API 健康检查（最多 180 秒）"
for i in $(seq 1 36); do
  if curl -fsS --max-time 3 http://127.0.0.1/api/v1/health >/dev/null 2>&1; then
    echo "API 已就绪"
    break
  fi
  printf "."
  sleep 5
  if [ "$i" -eq 36 ]; then
    echo
    docker compose $COMPOSE_ARGS ps
    docker compose $COMPOSE_ARGS logs api --tail 40
    die "API 在 180 秒内未就绪，请查看上面的日志"
  fi
done

say "初始化演示数据"
if docker compose $COMPOSE_ARGS exec -T api pnpm exec tsx prisma/seed.ts >/tmp/seed.log 2>&1; then
  tail -8 /tmp/seed.log
else
  echo "seed 未成功（可能数据已存在），日志："
  tail -15 /tmp/seed.log
fi

say "部署完成"
IP=$(curl -fsS --max-time 3 ifconfig.me 2>/dev/null || echo "<公网IP>")
cat <<EOF

----------------------------------------------
 访问地址
----------------------------------------------
 HTTP : http://${IP}/
 API  : http://${IP}/api/v1/health
 文档 : http://${IP}/docs

 演示账号：student.a@demo.shiguang.local
 密码    ：$(cat "$APP_DIR/demo-password.txt" 2>/dev/null || echo '见上一步输出')

 容器状态：
$(docker compose $COMPOSE_ARGS ps --format '  {{.Name}}  {{.Status}}')

 域名接入（Cloudflare）：
 1. DNS → A 记录 campus-life → ${IP}，开启代理（橙色云）
 2. SSL/TLS → 模式选 Full (strict)，并在 Origin Server 生成证书
 3. 证书放到 $APP_DIR/pkg-shiguang/infra/certs/ 后重跑本脚本
----------------------------------------------
EOF
